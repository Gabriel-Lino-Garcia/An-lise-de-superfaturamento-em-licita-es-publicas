import urllib.request
import bs4
from bs4 import BeautifulSoup
from pip._vendor import requests


from Tabelas import *
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine


engine = create_engine('sqlite:///sqlalchemy_example.db')
session = sessionmaker(bind=engine)
session = session()

url = 'https://www.telhanorte.com.br/materiais-de-construcao'
r = requests.get(url)
soup = BeautifulSoup(r.content)

for p in soup.find_all('p', attrs={'class': 'price'}):
        nameStuff = p.find('a')['title']
        for span in p.find_all('span', attrs={'class': 'newPrice'}):
         print(nameStuff)
         print(span.text)

         m = Material(nome = nameStuff, preco = span.text, urlsite = url)
         session.add(m)

session.commit()