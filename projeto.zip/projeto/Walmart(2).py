import urllib.request
import bs4
from bs4 import BeautifulSoup
from pip._vendor import requests

from Tabelas import *
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

engine = create_engine('sqlite:///sqlalchemy_example.db')
session = sessionmaker(bind=engine)
session = session()

url = 'https://www.walmart.com.br/categoria/casa-e-seguranca/materiais-de-construcao/?fq=C:1249/4429/'
r = requests.get(url)
soup = BeautifulSoup(r.content)
#print(soup)


print("-------- Materiais de Construção ----------")
print("-------- Respectivos Valores ----------")
for div in soup.findAll('div', attrs={'class': 'card-price-container'}):
    nameStuff = div.find('a')['title']
    for span in div.findAll('span', attrs={'class': 'price-value'}):
        print(nameStuff)
        print(span.text)

        m = Material(nome=nameStuff, preco=span.text, urlsite=url)
        session.add(m)

session.commit()