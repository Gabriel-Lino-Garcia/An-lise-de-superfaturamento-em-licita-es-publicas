
import urllib.request
import bs4
from bs4 import BeautifulSoup
from pip._vendor import requests
from Tabelas import *
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine


engine = create_engine('sqlite:///sqlalchemy_example.db')
session = sessionmaker(bind=engine)
session = session()

url = 'https://www.cec.com.br/material-de-construcao'
r = requests.get(url)
soup = BeautifulSoup(r.content)


for div in soup.find_all('div', attrs={'class': 'col-6 col-sm-4 product-list-tip'}):
    for span in div.find_all('span', attrs={'class': 'product-name'}):
        nameStuff = span.text
        print(nameStuff)
        for span2 in div.find_all('span', attrs={'class': 'product-price'}):
            preco = span2.text
            print(preco)

