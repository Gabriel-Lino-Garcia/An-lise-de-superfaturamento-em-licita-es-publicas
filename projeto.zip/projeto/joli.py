

import urllib.request
import bs4
from bs4 import BeautifulSoup
from pip._vendor import requests


from Tabelas import *
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

engine = create_engine('sqlite:///sqlalchemy_example.db')
session = sessionmaker(bind=engine)
session = session()

url = 'http://www.joli.com.br/promocoes.aspx'
r = requests.get(url)
soup = BeautifulSoup(r.content)

for div in soup.find_all('div', attrs={'id': 'pagina'}):
    for ul in div.find_all('ul', attrs={'class': 'list_carousel'}):
        for strong in ul.find_all('strong'):
            nameStuff = strong.text
            print(nameStuff)
        for p in ul.find_all('p', attrs={'class': 'preco'}):
            preco = p.text
            print(preco)

            m = Material(nome=nameStuff, preco=preco, urlsite= url)
            session.add(m)
assert isinstance(session, m)
session.commit()




