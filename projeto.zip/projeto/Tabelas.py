from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Material(Base):
    __tablename__ = 'materiais'

    id = Column(Integer, primary_key=True)
    nome = Column(String)
    preco = Column(String)
    urlsite = Column(String)

    def __repr__(self):
        return "<Material(nome='%s', preco='%s', url='%s')>" % (self.nome, self.preco, self.urlsite)